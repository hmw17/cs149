/**
* Description: This code implements name counter from given file.
* Author names:
* Author emails:
* Last modified date:
* Creation date:
**/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <pthread.h>
#include <stdint.h>

#define MAX_NAME 31
#define TABLE_SIZE 997


typedef struct ThreadData {
	pthread_t* thread;
	const char* fileName;
} ThreadData;

typedef struct HashNode {
	char* name;
	int count;
	struct HashNode* next;
} HashNode;
int log_index = 1;

HashNode** hashTable = NULL;
pthread_mutex_t* locks;
pthread_mutex_t logIndexLock;


/**
* This function calculates a hash value for a given string "line"
* based on the sum of the ASCII values of its characters.
* The hash value is then modulo-ed by the number of lines in the file.
* Input parameters: line (the string to calculate the hash for), linesCount (the number of lines in the file)
* Returns: an integer value (the calculated hash)
**/
int hash(const char* line)
{
	int hash_sum = 0, i = 0;

	for (i = 0; line[i] != '\0'; i++)
	{
		hash_sum += line[i];
	}

	return hash_sum % TABLE_SIZE;
}

void insertIntoTable(HashNode** hashTable, const char* name) {
    int hashIndex = hash(name);

    pthread_mutex_lock(&locks[hashIndex]);
    
    // If the slot is empty, insert the name directly
    if (hashTable[hashIndex] == NULL) {

    	hashTable[hashIndex] = (HashNode*)malloc(sizeof(HashNode));
        hashTable[hashIndex]->name = strdup(name);
        hashTable[hashIndex]->next = NULL;
        hashTable[hashIndex]->count = 1;
    } else {
        // Collision occurred, perform chaining
        // Traverse the chain until an empty slot is found
        HashNode* hashNode = hashTable[hashIndex];
        HashNode* prevNode = NULL;
        while (hashNode != NULL && strcmp(hashNode->name, name) != 0) {
            prevNode = hashNode;
            hashNode = hashNode->next;
        }
        
        // If the name is not already present, insert it
        if (hashNode == NULL) {
            HashNode* hashNodeNew = (HashNode*)malloc(sizeof(HashNode));
	        hashNodeNew->name = strdup(name);
	        hashNodeNew->next = NULL;
	        hashNodeNew->count = 1;
	        prevNode->next = hashNodeNew;
        } else {
            // Name already exists, increment its count
            (hashNode->count)++;
        }
    }

    pthread_mutex_unlock(&locks[hashIndex]);
}



/**
* This function opens a file with the name provided in the command line argument
* and returns a pointer to the opened file.
* If no filename is provided in the command line, it prints an error message to stderr and returns NULL.
* If the file cannot be opened, it also prints an error message to stderr.
* Input parameters: argc (the number of command line arguments), argv (an array of strings containing the command line arguments)
* Returns: a pointer to the opened file, or NULL if the file cannot be opened.
**/
FILE* openFile(const char* fileName)
{
	FILE* fin = fopen(fileName, "r");

	if (!fin)
	{
		fprintf(stderr, "File %s cannot be opened\n", fileName);
	}

	return fin;
}


char* getCurrentTimeString() {
    time_t currentTime;
    struct tm* timeInfo;
    char* timeString = (char*)malloc(20 * sizeof(char)); // Assuming the format "dd/MM/yyyy hh:mm:ss aa" fits within 20 characters

    if (timeString == NULL) {
        fprintf(stderr, "Failed to allocate memory for time string\n");
        return NULL;
    }

    // Get the current time
    time(&currentTime);
    timeInfo = localtime(&currentTime);

    // Format the time as a string
    strftime(timeString, 20, "%d/%m/%Y %I:%M:%S %p", timeInfo);

    return timeString;
}

void* processFileWithThreads(void* arg)
{
	// Cast the argument to the ThreadData structure
	ThreadData* data = (ThreadData*)arg;

	// Extract thread information
	pthread_t* thread = data->thread;
	uintptr_t threadAddressValue = (uintptr_t)thread;
	const char* fileName = data->fileName;

	int lIdx = 0;

	// Increment and retrieve the log index in a thread-safe manner
	pthread_mutex_lock(&logIndexLock);
	lIdx = log_index++;
	pthread_mutex_unlock(&logIndexLock);

	// Get the current time as a string
	char* timeStr = getCurrentTimeString();

	// Print log message indicating the thread creation
	printf("Logindex %d, thread %lx, PID %d, %s: This is thread %lx and I created THREADDATA %p\n",
		   lIdx, threadAddressValue, getpid(), timeStr, threadAddressValue, arg);

	// Free the memory allocated for the time string
	free(timeStr);

	// Increment and retrieve the log index again
	pthread_mutex_lock(&logIndexLock);
	lIdx = log_index++;
	pthread_mutex_unlock(&logIndexLock);

	// Get the current time as a string
	timeStr = getCurrentTimeString();

	// Print log message indicating the ability to access THREADDATA
	printf("Logindex %d, thread %lx, PID %d, %s: This is thread %lx and I can access THREADDATA %p\n",
		   lIdx, threadAddressValue, getpid(), timeStr, threadAddressValue, arg);

	// Free the memory allocated for the time string
	free(timeStr);

	// Open the input file
	FILE* fin = openFile(fileName);

	// If the file couldn't be opened, return an error code
	if (!fin)
	{
		return NULL;
	}

	// Increment and retrieve the log index again
	pthread_mutex_lock(&logIndexLock);
	lIdx = log_index++;
	pthread_mutex_unlock(&logIndexLock);

	// Get the current time as a string
	timeStr = getCurrentTimeString();

	// Print log message indicating the successful file opening
	printf("Logindex %d, thread %lx, PID %d, %s: Opened file %s\n",
		   lIdx, threadAddressValue, getpid(), timeStr, fileName);

	// Free the memory allocated for the time string
	free(timeStr);

	char line[MAX_NAME];
	int line_num = 1;

	// Loop through each line in the file
	while (fgets(line, MAX_NAME, fin))
	{
		// Remove the newline character at the end of the line
		line[strcspn(line, "\n")] = 0;

		// If the line is not empty, process it
		if (strlen(line) != 0)
		{
			// Calculate the hash value of the name and find an available slot in the array of names
			insertIntoTable(hashTable, line);
		}
		else
		{
			fprintf(stderr, "Warning - file %s Line %d is empty.\n", fileName, line_num);
		}

		line_num++;
	}

	// Close the file
	fclose(fin);

	// Increment and retrieve the log index again
	pthread_mutex_lock(&logIndexLock);
	lIdx = log_index++;
	pthread_mutex_unlock(&logIndexLock);

	// Get the current time as a string
	timeStr = getCurrentTimeString();

	// Print log message indicating the deletion of THREADDATA
	printf("Logindex %d, thread %lx, PID %d, %s: This is thread %lx and I delete THREADDATA\n", lIdx, threadAddressValue, getpid(), timeStr, threadAddressValue); 
	free(timeStr);
	free(arg);
	return NULL;
}

int main(int argc, char** argv)
{
	// Check if the number of command-line arguments is correct
	if (argc != 3)
	{
		// Print usage message to stderr and exit with failure code if there are no files specified
		fprintf(stderr, "Usage: %s file1 file2 \n", argv[0]);
		exit(EXIT_FAILURE);
	}

	// Allocate memory for the array of locks and hash table
	locks = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t) * TABLE_SIZE);
	hashTable = (HashNode**)malloc(sizeof(HashNode*) * TABLE_SIZE);

	// Initialize the log index lock and each individual lock in the locks array
	pthread_mutex_init(&logIndexLock, NULL);
	for (int i = 0; i < TABLE_SIZE; i++)
	{
		pthread_mutex_init(&locks[i], NULL);
		hashTable[i] = NULL;
	}

	// Print log message indicating the start of log messages section
	printf("==================Log Messages==================\n");

	// Create and process the first thread
	printf("Create first thread\n");
	pthread_t thread1;
	ThreadData* data1 = (ThreadData*)malloc(sizeof(ThreadData));
	data1->thread = &thread1;
	data1->fileName = argv[1];
	pthread_create(&thread1, NULL, processFileWithThreads, (void*)data1);

	// Create and process the second thread
	printf("Create second thread\n");
	pthread_t thread2;
	ThreadData* data2 = (ThreadData*)malloc(sizeof(ThreadData));
	data2->thread = &thread2;
	data2->fileName = argv[2];
	pthread_create(&thread2, NULL, processFileWithThreads, (void*)data2);

	// Wait for the first thread to finish
	pthread_join(thread1, NULL);
	printf("First thread exited\n");

	// Wait for the second thread to finish
	pthread_join(thread2, NULL);
	printf("Second thread exited\n");

	// Print log message indicating the start of name counts section
	printf("==================Name Counts==================\n");

	// Iterate over each slot in the hash table and print the names and their counts
	for (int i = 0; i < TABLE_SIZE; i++) {
		HashNode* currentNode = hashTable[i];
		if (currentNode != NULL) {
			while (currentNode != NULL) {
				printf("%s: %d\n", currentNode->name, currentNode->count);
				currentNode = currentNode->next;
			}
		}
	}

	// Destroy the log index lock and each individual lock in the locks array
	pthread_mutex_destroy(&logIndexLock);
	for (int i = 0; i < TABLE_SIZE; i++)
	{
		pthread_mutex_destroy(&locks[i]);

		// Free the memory allocated for each name and hash node in the hash table
		HashNode* currentNode = hashTable[i];
		while (currentNode != NULL)
		{
			HashNode* nextNode = currentNode->next;
			free(currentNode->name);
			free(currentNode);
			currentNode = nextNode;
		}
	}

	// Free the memory allocated for the hash table and locks array
	free(hashTable);
	free(locks);

	// Exit with success code
	return 0;
}


